﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerController : MonoBehaviour
{
	public float speed; // allows us to manage the speed from the inspector
	
	private Rigidbody rb; // assigns our player object's rigidbody to a rigidbody variable in our script
	
	
	
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
		
		
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis ("Horizontal"); // assigns horizontal movement to the float variable moveHorizontal
		float moveVertical = Input.GetAxis ("Vertical"); // assigns vertical movement to the float variable moveVertical
		
		// a vector3 is something in unity that can store a location within our scene. 
		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical); // this creates a new Vector3 that controls movement. The first value
		//in a vector3 in x, followed by y, and z. y is height, movement that would take our player up and down, and for the purpose of this tutorial
		//we don't need the player to be able to control the vertical movements of the player obejct.
		
		//the code that actually makes the player object move:
		rb.AddForce (movement * speed); // this adds the force in the direction determined by movement, which itself is determined by the keys that you're
		//pressing, and it multiplies this movement by the speed value that we will set in the inspector
		
    }
}
